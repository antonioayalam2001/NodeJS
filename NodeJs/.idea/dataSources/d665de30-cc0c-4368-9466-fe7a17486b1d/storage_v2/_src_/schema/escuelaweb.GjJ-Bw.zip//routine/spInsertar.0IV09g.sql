create
    definer = root@localhost procedure spInsertar(IN nombreCategoria varchar(50), IN descripcionCategoria varchar(50))
begin
insert into Categoria (nombreCategoria,descripcionCategoria) values (nombreCategoria,descripcionCategoria);
end;

