create
    definer = root@localhost procedure spActualizar(IN nombre varchar(50), IN descripcion varchar(50), IN idCat int)
begin
update Categoria set nombreCategoria = nombre,descripcionCategoria = descripcion where idCategoria = idCat;
end;

