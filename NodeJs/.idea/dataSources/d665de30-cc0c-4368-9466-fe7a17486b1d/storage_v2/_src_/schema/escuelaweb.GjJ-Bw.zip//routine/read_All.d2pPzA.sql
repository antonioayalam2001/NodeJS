create
    definer = root@localhost procedure read_All()
begin
select * from Categoria;
end;

