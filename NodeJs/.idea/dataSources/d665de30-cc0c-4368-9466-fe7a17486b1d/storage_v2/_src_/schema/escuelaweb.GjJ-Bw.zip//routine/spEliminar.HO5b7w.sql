create
    definer = root@localhost procedure spEliminar(IN id int)
begin
delete from categoria where idCategoria = id ;
end;

