create
    definer = root@localhost procedure read_one(IN id int)
select * from Categoria where idCategoria = id;

